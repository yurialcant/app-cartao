import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'screens/login_screen.dart';
import 'screens/dashboard_screen.dart';
import 'screens/welcome_screen.dart';
import 'screens/first_access_method_screen.dart';
import 'screens/first_access_token_screen.dart';
import 'screens/first_access_register_screen.dart';
import 'screens/forgot_password_screen.dart';
import 'screens/device_token_screen.dart';

import 'themes/app_theme.dart';

class MyApp extends StatelessWidget {
  final String initialRoute;

  const MyApp({super.key, required this.initialRoute});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Carteira de Benefícios',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [
        Locale('pt', 'BR'),
        Locale('en', 'US'),
      ],
      initialRoute: initialRoute,
      routes: {
        '/welcome': (_) => const WelcomeScreen(),
        '/login': (_) => const LoginScreen(),
        '/first_access': (_) => const FirstAccessMethodScreen(),
        '/first_access_token': (_) => const FirstAccessTokenScreen(),
        '/first_access_register': (_) => const FirstAccessRegisterScreen(),
        '/forgot_password': (_) => const ForgotPasswordScreen(),
        '/device_token': (_) => const DeviceTokenScreen(),
        '/dashboard': (_) => const DashboardScreen(),
      },
    );
  }
}
