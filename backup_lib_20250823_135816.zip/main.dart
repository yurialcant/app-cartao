import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'app.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Trava orientação em portrait (vertical)
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
  ]);

  // Aqui você pode verificar se o usuário já está logado
  // Por enquanto, sempre começamos na tela de boas-vindas
  const String initialRoute = '/welcome';

  runApp(MyApp(initialRoute: initialRoute));
}
