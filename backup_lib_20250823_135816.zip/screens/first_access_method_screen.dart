import 'package:flutter/material.dart';
import '../widgets/custom_button.dart';

class FirstAccessMethodScreen extends StatelessWidget {
  const FirstAccessMethodScreen({super.key});

  void _selectMethod(BuildContext context, String method) {
    // Simula chamada de API para envio do token por SMS ou E-mail
    Future.delayed(const Duration(milliseconds: 500), () {
      Navigator.pushNamed(context, '/first_access_token'); // Próxima etapa
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Primeiro Acesso'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Como você quer receber seu código de primeiro acesso?',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 24),
            CustomButton(
              label: 'Receber por SMS',
              onPressed: () => _selectMethod(context, 'sms'),
            ),
            const SizedBox(height: 16),
            CustomButton(
              label: 'Receber por E-mail',
              onPressed: () => _selectMethod(context, 'email'),
            ),
          ],
        ),
      ),
    );
  }
}
