import 'package:flutter/material.dart';
import '../widgets/otp_input_fields.dart';

class FirstAccessTokenScreen extends StatefulWidget {
  const FirstAccessTokenScreen({super.key});

  @override
  State<FirstAccessTokenScreen> createState() => _FirstAccessTokenScreenState();
}

class _FirstAccessTokenScreenState extends State<FirstAccessTokenScreen> {
  final List<TextEditingController> _controllers =
      List.generate(6, (_) => TextEditingController());

  void _onContinue() {
    String code = _controllers.map((c) => c.text).join();

    if (code.length != 6) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Código incompleto')),
      );
      return;
    }

    // Simula validação do token
    Future.delayed(const Duration(milliseconds: 500), () {
      Navigator.pushNamed(context, '/first_access_register');
    });
  }

  @override
  void dispose() {
    for (var c in _controllers) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Código de Verificação'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Enviamos um código de 6 dígitos para você.',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 24),
            OtpInputFields(controllers: _controllers),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                onPressed: _onContinue,
                child: const Text('Continuar'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
