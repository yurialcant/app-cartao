// lib/services/auth_service.dart
import 'dart:async';

class AuthService {
  static final Map<String, String> _mockUsers = {
    '123.456.789-00': 'senha123',
    '987.654.321-00': 'abc123',
    '111.222.333-44': 'teste456',
  };

  static final Set<String> _firstAccessCPFs = {
    '123.456.789-00',
    '111.222.333-44',
  };

  Future<bool> login(String cpf, String password) async {
    await Future.delayed(const Duration(seconds: 1)); // simula delay
    return _mockUsers[cpf] == password;
  }

  Future<bool> isFirstAccess(String cpf) async {
    await Future.delayed(const Duration(milliseconds: 500));
    return _firstAccessCPFs.contains(cpf);
  }

  Future<bool> validateToken(String token) async {
    await Future.delayed(const Duration(milliseconds: 500));
    return token == '123456' || token == '654321';
  }

  Future<bool> registerPassword(String cpf, String password) async {
    await Future.delayed(const Duration(milliseconds: 800));
    _mockUsers[cpf] = password;
    _firstAccessCPFs.remove(cpf);
    return true;
  }

  Future<bool> sendRecovery(String email) async {
    await Future.delayed(const Duration(seconds: 1));
    return email.contains('@');
  }
}
