// lib/services/token_service.dart
import 'dart:async';

enum DeliveryMethod { sms, email }

class TokenService {
  static const _validTokens = {
    '123456',
    '654321',
    '111111',
  };

  Future<bool> sendToken({
    required String cpf,
    required DeliveryMethod method,
  }) async {
    await Future.delayed(const Duration(seconds: 1));

    // Mock: apenas imprime o envio
    print('Enviando token para $cpf via ${method.name.toUpperCase()}');

    // Sempre retorna true no mock
    return true;
  }

  Future<bool> validateToken(String token) async {
    await Future.delayed(const Duration(milliseconds: 500));
    return _validTokens.contains(token);
  }
}
