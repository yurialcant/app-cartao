import 'package:flutter/material.dart';

class OtpInputFields extends StatelessWidget {
  final List<TextEditingController> controllers;
  final void Function(String)? onCompleted;

  const OtpInputFields({
    super.key,
    required this.controllers,
    this.onCompleted,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: List.generate(controllers.length, (index) {
        return SizedBox(
          width: 40,
          child: TextField(
            controller: controllers[index],
            keyboardType: TextInputType.number,
            textAlign: TextAlign.center,
            maxLength: 1,
            onChanged: (value) {
              if (value.isNotEmpty && index < controllers.length - 1) {
                FocusScope.of(context).nextFocus();
              }
              if (onCompleted != null && controllers.every((c) => c.text.isNotEmpty)) {
                final code = controllers.map((c) => c.text).join();
                onCompleted!(code);
              }
            },
            decoration: const InputDecoration(
              counterText: '',
              border: OutlineInputBorder(),
            ),
          ),
        );
      }),
    );
  }
}
